/*package All;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class MyClass {
	 public static Connection dataBaseConnection = null;
		public static Statement statement = null;
		public static ResultSet resultSet = null;
	
	 public static void main(String[] args) {
	
		
		 try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			dataBaseConnection = DriverManager.getConnection("jdbc:Oracle:thin:@ldaps://oam-oud-dmz.safeway.com:636/MEAMQA_app,cn=oraclecontext,dc=safeway,dc=com","TTAMI00","Food$123");
			System.out.println(" DB Connection is Successful");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
		}		
					
		 */
	    
	   
	