package AMP.Pages;

import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


import AMP.Modules.BaseClass;
import AMP.Modules.DivisionExcPageobject;
import AMP.Modules.LoginPageobject;


public class AA123_DivisionExclusion extends BaseClass {

	WebDriver Driver;

	LoginPageobject LPO = new LoginPageobject(Driver);
	DivisionExcPageobject DEPO = new DivisionExcPageobject(Driver);
	
	static ExtentTest test;

	static ExtentReports report;

	@Test(priority = 1, enabled = true)
	public void LoginTC() throws Exception {
		
		LPO.waitforelement();
		LPO.TC01_Login();

	}
	@Test(priority = 2, enabled = true)
	public void FirstTC() throws Exception {
		
		DEPO.Menu(Driver);
		DEPO.waitForSpinnerToBeGone(Driver);
		
		Thread.sleep(20000);

	}
	@Test(priority = 3, enabled = true)
	public void SecondTC() throws Exception {
		
		DEPO.waitforDivexcl(Driver);
		DEPO.ExclsnDivsn(Driver);
		DEPO.ExcldDivtbl(Driver);
		
	}
	@Test(priority = 4, enabled = true)
	public void ThirdTC() throws Exception {
		
		DEPO.RemvDivtbl(Driver); 
		
	}
	
	@BeforeTest
	public void beforeTest() throws InterruptedException {

		
		Driver = LPO.beforeTest();
		DEPO.beforeTest(Driver);
		//Thread.sleep(10000);
		extentTest = extent.startTest("AMP Test", "AA-123-Login");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
		
	}

	@AfterTest
	public void after() {

		Driver.quit();

	}
}
