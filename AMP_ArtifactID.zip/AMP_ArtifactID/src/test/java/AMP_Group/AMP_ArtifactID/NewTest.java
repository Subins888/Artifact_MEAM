package AMP_Group.AMP_ArtifactID;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.chrome.ChromeDriver;

public class NewTest {
      WebDriver Driver;
//For browser control
   
      @Test
      public void search() throws InterruptedException  {

    	  
    	  Driver.findElement(By.name("q")).sendKeys("UST Global");
    	  
    	  Driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
    	  
    	  Thread.sleep(5000);
    	  
    	  Driver.findElement(By.linkText("About Us")).sendKeys(Keys.ENTER);
    	  
    	  
            }
            
   

      @BeforeTest
      public WebDriver beforeTest() {

            System.setProperty("webdriver.chrome.driver",
                        new File(System.getProperty("user.dir"), "chromedriver.exe")
                                    .getAbsolutePath());
            Driver = new ChromeDriver();
            Driver.get("https://www.google.com");
            return Driver;

      }

      @AfterTest
      public WebDriver afterTest() {
    	  
    	  System.out.println("Test Case 1 -Passed");
    	  
            Driver.quit();

            return Driver;

      }    
      
      
}
