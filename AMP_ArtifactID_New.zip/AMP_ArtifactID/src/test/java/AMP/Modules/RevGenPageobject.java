package AMP.Modules;

//import java.io.File;
//import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.By;
//import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

/*import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;*/

public class RevGenPageobject extends BaseClass {

	WebDriver Driver;
	LoginPageFactory LF = new LoginPageFactory(Driver);
	RevGenPageFactory RGF = new RevGenPageFactory(Driver);
	static ExtentTest test;

	static ExtentReports report;

	public RevGenPageobject(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		String source1 = ts.getScreenshotAs(OutputType.BASE64);
		return source1;

	}

	public String waitforelement() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(RGF.Next));

		return null;
	}
	public String waitForSpinnerToBeGone(WebDriver Driver) {

		//By loadingImage = By.id("amp-spinner");
		
		By loadingImage = By
		.xpath("*[@id='amp-spinner']");

		// WebDriverWait wait = new WebDriverWait(Driver);
		//
		// wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingImage));

		WebDriverWait wait = new WebDriverWait(Driver, 120);
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		return null;
	}
	
	
	public void WaitstartGen(WebDriver Driver) {
		WebDriverWait wait = new WebDriverWait(Driver, 200);
		wait.until(ExpectedConditions.textToBePresentInElement(RGF.GencompMsg, "Revenue generation started..."));

	}
	
	public void WaitDSDGen(WebDriver Driver) {
		WebDriverWait wait = new WebDriverWait(Driver, 300);
		wait.until(ExpectedConditions.textToBePresentInElement(RGF.GencompMsg, "DSD in progress..."));

	}
	
	public void WaitUNITEDGen(WebDriver Driver) {
		WebDriverWait wait = new WebDriverWait(Driver, 300);
		wait.until(ExpectedConditions.textToBePresentInElement(RGF.GencompMsg, "UNITED in progress..."));

	}
	public void WaitWHSEGen(WebDriver Driver) {
		WebDriverWait wait = new WebDriverWait(Driver, 300);
		wait.until(ExpectedConditions.textToBePresentInElement(RGF.GencompMsg, "WHSE in progress..."));

	}
	public void WaitSBTGen(WebDriver Driver) {
		WebDriverWait wait = new WebDriverWait(Driver, 300);
		wait.until(ExpectedConditions.textToBePresentInElement(RGF.GencompMsg, "SBT in progress..."));

	}  
	
	public void WaitcompltGen(WebDriver Driver) {
		WebDriverWait wait = new WebDriverWait(Driver, 300);
		wait.until(ExpectedConditions.textToBePresentInElement(RGF.GencompMsg, "Revenue generation completed!"));

	}

	
	@Test
	public void Menu(WebDriver Driver) throws Exception {

		//RGF.Dashboard.click();
		Thread.sleep(1000);
		RGF.Revenueclk();
		
		RGF.Generateclk();
		Thread.sleep(10000);

	}

	@Test
	public void Generate(WebDriver Driver) throws Exception {

		Thread.sleep(5000);
		RGF.Period_drop.sendKeys("202002", Keys.ENTER);

		Thread.sleep(5000);

		RGF.GenButton.click();
	}

	public void GenPopup(WebDriver Driver) {

		try {
			if (RGF.YesGenPopup.isDisplayed()) {
				RGF.YesGenPopup.click();
		
			}else {

			System.out.println("First time generation for this selected Period");
		} }catch (Exception e) {
	}}

	//MessageGeneration
	
	public String GenerateStart(WebDriver Driver) {
		
		
		String txt = RGF.GencompMsg.getText();
		
		try {
		if (txt.contains("Revenue generation started")) {
			System.out.println("Revenue generation started message is displaying in home page");
			extentTest.log(LogStatus.INFO, "Revenue generation started message is displaying in home page");
		} else {
			System.out.println("Revenue generation started message is not displaying in home page");
			extentTest.log(LogStatus.FAIL, "Revenue generation started message is not displaying in home page");
			Assert.assertTrue(txt.contains("Revenue generation started"));
		}
		} catch (Exception e) {

			System.out.println("Revenue generation started message was gone");
		}
		
		return null;
		}	

	
	public String GenerateDSD(WebDriver Driver) {
		String txt = RGF.GencompMsg.getText();
		try {
		if (txt.contains("DSD in progress...")) {
			System.out.println("DSD in progress... message is displaying in home page");
			extentTest.log(LogStatus.INFO, "DSD in progress... message is displaying in home page");
		} else {
			System.out.println("DSD in progress... message is not displaying in home page");
			extentTest.log(LogStatus.FAIL, "DSD in progress... message is not displaying in home page");
			Assert.assertTrue(txt.contains("DSD in progress..."));
		}
	} catch (Exception e) {

		System.out.println("DSD in progress... message was gone");
	}
		return null;

	}
	
	public String GenerateUNITED(WebDriver Driver) {
		String txt = RGF.GencompMsg.getText();
		try {
		if (txt.contains("UNITED in progress...")) {
			System.out.println("UNITED in progress... message is displaying in home page");
			extentTest.log(LogStatus.INFO, "UNITED in progress... message is displaying in home page");
		} else {
			System.out.println("UNITED in progress... message is not displaying in home page");
			extentTest.log(LogStatus.FAIL, "UNITED in progress... message is not displaying in home page");
			Assert.assertTrue(txt.contains("UNITED in progress..."));
		}
	} catch (Exception e) {

		System.out.println("UNITED in progress... message was gone");
	}
		return null;

	}
	
	public String GenerateWHSE(WebDriver Driver) {
		String txt = RGF.GencompMsg.getText();
		try {
		if (txt.contains("WHSE in progress...")) {
			System.out.println("WHSE in progress... message is displaying in home page");
			extentTest.log(LogStatus.INFO, "WHSE in progress... message is displaying in home page");
		} else {
			System.out.println("WHSE in progress... message is not displaying in home page");
			extentTest.log(LogStatus.FAIL, "WHSE in progress... message is not displaying in home page");
			Assert.assertTrue(txt.contains("WHSE in progress..."));
		}
	} catch (Exception e) {

		System.out.println("WHSE in progress... message was gone");
	}
		return null;

	}
	
	public String GenerateSBT(WebDriver Driver) {
		String txt = RGF.GencompMsg.getText();
		try {
		if (txt.contains("SBT in progress...")) {
			System.out.println("SBT in progress... message is displaying in home page");
			extentTest.log(LogStatus.INFO, "SBT in progress... message is displaying in home page");
		} else {
			System.out.println("SBT in progress... message is not displaying in home page");
			extentTest.log(LogStatus.FAIL, "SBT in progress... message is not displaying in home page");
			Assert.assertTrue(txt.contains("SBT in progress..."));
		}
	} catch (Exception e) {

		System.out.println("SBT in progress... message was gone");
	}
		return null;

	}  
		
	public String GenerateDis(WebDriver Driver) {
		String txt = RGF.GencompMsg.getText();
		try {
		if (txt.contains("Revenue generation completed!")) {
			System.out.println("Revenue generation completed! message is displaying in home page");
			extentTest.log(LogStatus.INFO, "Revenue generation completed! message is displaying in home page");
		} else {
			System.out.println("Revenue generation completed! message is not displaying in home page");
			extentTest.log(LogStatus.FAIL, "Revenue generation completed! message is not displaying in home page");
			Assert.assertTrue(txt.contains("Revenue generation completed!"));
		}
	} catch (Exception e) {

		System.out.println("Revenue generation completed! message was gone");
	}
		return null;

	}
	


	@BeforeTest
	public void beforeTest(WebDriver Driver) {

		RGF = new RevGenPageFactory(Driver);

	}


}
