/*package AMP_Group.AMP_ArtifactID;

//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SSGenericFactory {
	WebDriver Driver;

	//@FindBy(xpath = "//*[@id=\'i0116\']")
	//WebElement Ldap;
	
	@FindBy(xpath = "//*[@id=\'idSIButton9\']")
	WebElement Next;
	
	@FindBy(xpath = "//*[@id='userNameInput']")
	WebElement Username;

	@FindBy(xpath = "//*[@id=\'passwordInput\']")
	WebElement Password;
	
	@FindBy(xpath = "//*[@id=\'submitButton\']")
	WebElement SignIn;
	
	@FindBy(xpath = "/html/body/app-root/amp-container/div/div[1]/div/amp-navbar/nav/div[3]/div[1]")
	WebElement Ldapname;
	
	@FindBy(xpath = "/html/body/app-root/amp-container/div/div[1]/div/amp-navbar/nav/div[3]/div[3]/span")
	WebElement Logout;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[1]/div/amp-navbar/nav/div[2]/ul/li[2]")
	WebElement Revenueclk;
	
	@FindBy(xpath ="//*[@id=\'ngb-popover-0\']/div[2]/amp-menu-pop-over/div/div[1]")
	WebElement Generateclk;
	
	@FindBy(xpath="//*[@id='period']/div/div/div[2]/input")
	WebElement Period_drop;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[2]/div/div[2]/amp-generate/div/form/div/button[1]")
	WebElement GenButton;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[2]/div/div[2]/amp-generate/amp-stepper/div/div/div")
	WebElement GencompMsg;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[2]/div/div[2]/amp-generate/amp-modal/div/div/div/div[3]/button[1]")
	WebElement YesGenPopup;
	
	public SSGenericFactory(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

}
*/