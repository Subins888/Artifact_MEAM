/*package AMP_Group.AMP_ArtifactID;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

*//**
 * 
 * 
 * @author jmaya09
 *
 *//*

public abstract class BaseClass {

	public static ExtentReports extent;
	public static ExtentTest extentTest;
	WebDriver Driver;

	// public abstract String getTestCaseName();
	// public abstract String getTestCaseDescription();

	@BeforeSuite
	public void setup() throws IOException {

		String extentReportFile = System.getProperty("user.dir") + "\\extentReportFile.html";
		extent = new ExtentReports(extentReportFile, true);

	}

	@AfterMethod
	public void getResult(ITestResult result) throws IOException {

		if (result.getStatus() == ITestResult.FAILURE) {
			extentTest.log(LogStatus.FAIL, " Test case Execution STOPPED");
			System.out.println("Fail");
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			extentTest.log(LogStatus.PASS, " Test Case Execution Completed");
		} else {
			extentTest.log(LogStatus.SKIP, " Test Case SKIPPED");
		}

	}

	@AfterSuite
	public void tearDown() {
		extent.flush();

	}
}
*/