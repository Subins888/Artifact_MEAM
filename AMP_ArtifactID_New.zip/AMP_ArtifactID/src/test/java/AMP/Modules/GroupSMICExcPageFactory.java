package AMP.Modules;

import org.openqa.selenium.Keys;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GroupSMICExcPageFactory {
	WebDriver Driver;

	@FindBy(xpath = "//*[@id=\'idSIButton9\']")
	WebElement Next;
	
	@FindBy(xpath ="//li[contains(text(),'Dashboard')]")
	WebElement Dashboard;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[1]/div/amp-navbar/nav/div[2]/ul/li[3]")
	WebElement Admin;	
	
	@FindBy(xpath ="//div[contains(text(),'GROUP and SMIC Exclusion')]")
	WebElement GrpSmexcl;
	
	@FindBy(xpath ="//div[@class='ng-input']//input")
	WebElement Group;
	
	@FindBy(xpath = "//textarea[@id='label']")
	WebElement Reason;
	
	@FindBy(xpath = "//button[@id='excludeGroup']")
	WebElement Excldbtn;
	
	@FindBy(xpath ="//p[contains(text(),'01 - CANDY, GUM & MINTS')]")
	WebElement Grpcol;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[2]/div/div[2]/amp-upc-exclusion/div/form/div[3]/amp-datatable/div/div/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[7]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span/p")
	WebElement UPCcol;
	
	public GroupSMICExcPageFactory(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	
	public void GrpSmclk() 
	{
			Admin.click();
			GrpSmexcl.click();
	}
	public void Groupselect() 
	{
		Group.click();
		Group.sendKeys("01", Keys.ENTER);
		
	
	}
	
	public void Exclude1() 
	{
		
		Reason.sendKeys("Test Automation Group", Keys.ENTER);
		Excldbtn.click();
	
	}
}
