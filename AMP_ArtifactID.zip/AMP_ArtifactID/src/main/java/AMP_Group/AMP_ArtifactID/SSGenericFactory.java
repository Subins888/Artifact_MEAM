package AMP_Group.AMP_ArtifactID;

//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SSGenericFactory {
       WebDriver Driver;
       
       @FindBy(name="userName")
       WebElement Username;
       
       @FindBy(name="password")
       WebElement Password;
       
       @FindBy(name="submit")
       WebElement Submit;
       
@FindBy(xpath="/html/body/div[2]/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table/tbody/tr/td[1]/a")
       WebElement SignOn;
       

       public SSGenericFactory(WebDriver Driver) {
              this.Driver = Driver;
              PageFactory.initElements(Driver, this);
       }


}
