package AMP_Group.AMP_ArtifactID;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class SSPageObject  { //extends ExtendBaseClass

      WebDriver Driver;
      SSGenericFactory GF = new SSGenericFactory(Driver);
      static ExtentTest test;

      static ExtentReports report;

      public SSPageObject(WebDriver Driver) {
            this.Driver = Driver;
            PageFactory.initElements(Driver, this);
      }

      public String waitforelement() {

            WebDriverWait wait = new WebDriverWait(Driver, 60);
      wait.until(ExpectedConditions.elementToBeClickable(GF.Submit));
            return null;
      }

      @BeforeClass
      public static void startTest()

      {

            report = new ExtentReports(System.getProperty("user.dir")
                        + "\\ExtentReportResults.html");

            test = report.startTest("ExtentDemo");

      }

      @Test
      public String Login() throws BiffException, IOException,
                  InterruptedException {

            String file = new File(System.getProperty("user.dir"), "TestData.xls")
                        .getAbsolutePath();

            FileInputStream fi = new FileInputStream(file);

            Workbook w = Workbook.getWorkbook(fi);
            Sheet s = w.getSheet(0);

            try {
                  for (int i = 1; i < s.getRows(); i++) {
                        // Read data from excel sheet

                        String s3 = s.getCell(1, i).getContents();
                        String s4 = s.getCell(2, i).getContents();
                        Thread.sleep(3000);

                        GF.Username.sendKeys(s3);
                        Thread.sleep(2500);

                        GF.Password.sendKeys(s4);
                        Thread.sleep(2500);

                        GF.Submit.click();
                        Thread.sleep(2500);

                        GF.SignOn.click();
                  }
            } catch (Exception e) {
                  System.out.println(e);
            }

            return null;

      }

      @BeforeTest
      public WebDriver beforeTest() {

            System.setProperty("webdriver.chrome.driver",
                        new File(System.getProperty("user.dir"), "chromedriver.exe")
                                    .getAbsolutePath());
            Driver = new ChromeDriver();

            GF = new SSGenericFactory(Driver);
      Driver.get("http://demo.guru99.com/test/newtours/index.php");
            Driver.manage().window().maximize();

            return Driver;

      }

      @AfterClass
      public static void endTest()

      {

            report.endTest(test);
            report.flush();

      }

      @AfterTest
      public WebDriver afterTest() {
    	  System.out.println("Test Cases are Passed");
            Driver.quit();

            return Driver;

      }

}
