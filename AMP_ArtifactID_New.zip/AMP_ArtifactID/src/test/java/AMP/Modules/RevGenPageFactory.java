package AMP.Modules;

//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RevGenPageFactory {
	WebDriver Driver;

	
	@FindBy(xpath = "//*[@id=\'idSIButton9\']")
	WebElement Next;
	
	@FindBy(xpath ="//li[contains(text(),'Dashboard')]")
	WebElement Dashboard;
	
	@FindBy(xpath ="/html[1]/body[1]/app-root[1]/amp-container[1]/div[1]/div[1]/div[1]/amp-navbar[1]/nav[1]/div[2]/ul[1]/li[2]")
	WebElement Revenuex;
	
	@FindBy(xpath ="//*[@id=\'ngb-popover-0\']/div[2]/amp-menu-pop-over/div/div[1]")
	WebElement Generatex;
	
	@FindBy(xpath="//*[@id='period']/div/div/div[2]/input")
	WebElement Period_drop;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[2]/div/div[2]/amp-generate/div/form/div/button[1]")
	WebElement GenButton;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[2]/div/div[2]/amp-generate/amp-stepper/div/div/div")
	WebElement GencompMsg;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[2]/div/div[2]/amp-generate/amp-modal/div/div/div/div[3]/button[1]")
	WebElement YesGenPopup;
	
	
	
	public RevGenPageFactory(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public void Revenueclk() 
	{
		Revenuex.click();	
	}
	public void Generateclk() 
	{
		Generatex.click();	
	}
	
}
