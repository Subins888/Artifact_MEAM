package AMP.Modules;


//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DivisionExcPageFactory {
	WebDriver Driver;

	@FindBy(xpath = "//*[@id=\'idSIButton9\']")
	WebElement Next;
	
	@FindBy(xpath ="//li[contains(text(),'Dashboard')]")
	WebElement Dashboard;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[1]/div/amp-navbar/nav/div[2]/ul/li[3]")
	WebElement Admin;	
	
	@FindBy(xpath ="//div[contains(text(),'Division Exclusion')]")
	WebElement Divexcl;
	
	@FindBy(xpath ="//label[contains(text(),'01-Albertsons Specialty Care')]")
	WebElement Divdata;
	
	@FindBy(xpath = "//button[@name='addBtn']")
	WebElement Addbtn;
	
	@FindBy(xpath = "//div[@class='dual-list']//div[1]//div[2]//button[1]")
	WebElement Allbtn;
	
	@FindBy(xpath = "//button[@id='saveBtn']")
	WebElement Savebtn;
	
	@FindBy(xpath ="//button[@name='removeBtn']//parent::div[1]//label[contains(text(),'01-Albertsons Specialty Care')]")
	WebElement DivicolR;
	
	@FindBy(xpath = "//button[@name='removeBtn']")
	WebElement Removebtn;
	
	@FindBy(xpath ="//button[@name='addBtn']//parent::div[1]//label[contains(text(),'01-Albertsons Specialty Care')]")
	WebElement DivicolA;
	
	public DivisionExcPageFactory(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	
	public void Divisionclk() 
	{
			Admin.click();
			Divexcl.click();
	}
	public void Divisionselect() 
	{
		Divdata.click();
	
	}
	
	public void Exclude1() 
	{
		Addbtn.click();
		Savebtn.click();
	}
	public void Remove() 
	{
		Divdata.click();
		Removebtn.click();
		Savebtn.click();
	}
}
