/*package AMP_Group.AMP_ArtifactID;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class LoginPageobject extends BaseClass {

	WebDriver Driver;
	SSGenericFactory GF = new SSGenericFactory(Driver);
	static ExtentTest test;

	static ExtentReports report;

	public LoginPageobject(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		String source1 = ts.getScreenshotAs(OutputType.BASE64);
		return source1;

	}

	public String waitforelement() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(GF.Next));

		return null;
	}


	@Test
	public String TC01_Login() throws BiffException, IOException, InterruptedException {

		String file = new File(System.getProperty("user.dir"), "TestData.xls").getAbsolutePath();

		FileInputStream fi = new FileInputStream(file);

		Workbook w = Workbook.getWorkbook(fi);
		Sheet s = w.getSheet(0);

		try {
			for (int i = 1; i < s.getRows(); i++) {
				// Read data from excel sheet

				String s3 = s.getCell(1, i).getContents();
				String s4 = s.getCell(2, i).getContents();
				String s6 = s.getCell(4, i).getContents();
				Thread.sleep(3000);
				
				//GF.Ldap.sendKeys(s6);
				Thread.sleep(2500);
				
				GF.Next.click();
				Thread.sleep(5000);
				
				GF.Username.clear();

				GF.Username.sendKeys(s3);
				Thread.sleep(2500);

				GF.Password.sendKeys(s4);
				Thread.sleep(2500);

				GF.SignIn.click();
				Thread.sleep(5000);

			}
		} catch (Exception e) {
			System.out.println(e);
		
		}
		return null;
	}
	
	@Test
	public void TC06_LDAPtxt() throws BiffException, IOException, InterruptedException 
	{
		Thread.sleep(2500);
		String ldapnametxt = GF.Ldapname.getText();
		Assert.assertTrue( ldapnametxt.contains ("SSUBR13"));
		System.out.println(ldapnametxt);
		extentTest.log(LogStatus.INFO, ldapnametxt);
		
//		if (ldapnametxt.contains("SSUBR13")) {
//			System.out.println("Correct LDAP displaying in home page");
//			extentTest.log(LogStatus.INFO, "Correct LDAP displaying in home page");
//		} else {
//			System.out.println("Incorrect LDAP displaying in home page");
//			extentTest.log(LogStatus.FAIL, "Incorrect LDAP displaying in home page");
//			Assert.assertTrue(ldapnametxt.contains("SSUBR13"));
//		}
		
		
	}
			
		
//		try {
//	String ldapnametxt = 	GF.Ldapname.getText();
//		Assert.assertEquals( ldapnametxt, "SSUBR13");
//		
//		extentTest.log(LogStatus.INFO, ldapnametxt);
//		}catch(Exception e)
//		{
//			System.out.println(e);
//			extentTest.log(LogStatus.INFO, e);
//			throw e;
//		}
//	
	@Test
	public void TC07_Logout() throws BiffException, IOException, InterruptedException 
	{
		GF.Logout.click();
		
	}
	


	@BeforeTest
	public WebDriver beforeTest() {

		System.setProperty("webdriver.chrome.driver",
				new File(System.getProperty("user.dir"), "chromedriver.exe").getAbsolutePath());

		Driver = new ChromeDriver();
		GF = new SSGenericFactory(Driver);

		Driver.get("https://ig-meamqa.safeway.com/meamf/static/");
		//Driver.get("https://meam-dev.safeway.com/meamf/static/");
		
		Driver.manage().window().maximize();

		return Driver;

	}


}
*/