package AMP.Modules;

//import java.io.File;
//import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.By;
//import org.openqa.selenium.By;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


/*import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;*/

public class GroupSMICExcPageobject extends BaseClass {

	WebDriver Driver;
	LoginPageFactory LF = new LoginPageFactory(Driver);
	GroupSMICExcPageFactory GSGF = new GroupSMICExcPageFactory(Driver);
	
	static ExtentTest test;
	static ExtentReports report;

	public GroupSMICExcPageobject (WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		String source1 = ts.getScreenshotAs(OutputType.BASE64);
		return source1;

	}

	public String waitforelement() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(GSGF.Next));

		return null;
	}
	public String waitForSpinnerToBeGone(WebDriver Driver) {

		//By loadingImage = By.id("amp-spinner");
		By loadingImage = By
		.xpath("*[@id='amp-spinner']");
		// WebDriverWait wait = new WebDriverWait(Driver);
		// wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingImage));
		WebDriverWait wait = new WebDriverWait(Driver, 300);
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		return null;
	}
	

	
	@Test
	public void Menu(WebDriver Driver) throws Exception {

		Thread.sleep(1000);
		GSGF.GrpSmclk();
		Thread.sleep(5000);

	}

	@Test
	public void ExclsnGRP(WebDriver Driver) throws Exception {

		Thread.sleep(5000);
		GSGF.Groupselect();
		GSGF.Exclude1();
		
		
	}
	
	@Test
	public void ExcldGRPtbl(WebDriver Driver) throws InterruptedException  {

		Thread.sleep(5000);
		
		String Val1 = GSGF.Grpcol.getText() ;
		
		if (Val1.contains("01 - CANDY, GUM & MINTS")) {
			System.out.println("Pass");
			extentTest.log(LogStatus.INFO, "Group excluded");
		} else {
			System.out.println("Failed" );
			extentTest.log(LogStatus.FAIL, "Failed");
			}		
	}
		

	
	
	
	

	@BeforeTest
	public void beforeTest(WebDriver Driver) {

		GSGF = new GroupSMICExcPageFactory(Driver);

	}


}
