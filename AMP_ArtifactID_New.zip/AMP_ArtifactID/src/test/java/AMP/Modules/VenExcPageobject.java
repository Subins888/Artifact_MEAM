package AMP.Modules;

//import java.io.File;
//import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.By;
//import org.openqa.selenium.By;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


/*import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;*/

public class VenExcPageobject extends BaseClass {

	WebDriver Driver;
	LoginPageFactory LF = new LoginPageFactory(Driver);
	VenExcPageFactory VGF = new VenExcPageFactory(Driver);
	
	static ExtentTest test;
	static ExtentReports report;

	public VenExcPageobject(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		String source1 = ts.getScreenshotAs(OutputType.BASE64);
		return source1;

	}

	public String waitforelement() {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(VGF.Next));

		return null;
	}
	public String waitforvendexcl(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 150);
		wait.until(ExpectedConditions.elementToBeClickable(VGF.Vendhead));

		return null;
	}
	public String waitforhome(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(VGF.Searchbtn));

		return null;
	}
	
	public String waitForSpinnerToBeGone(WebDriver Driver) {

		//By loadingImage = By.id("amp-spinner");
		By loadingImage = By
		.xpath("*[@id='amp-spinner']");
		// WebDriverWait wait = new WebDriverWait(Driver);
		// wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingImage));
		WebDriverWait wait = new WebDriverWait(Driver, 300);
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		return null;
	}
	

	
	@Test
	public void Menu(WebDriver Driver) throws Exception {

		//Thread.sleep(1000);
		//Driver.navigate().refresh();
		VGF.Vendclk();
		Thread.sleep(5000);

	}

	@Test
	public void ExclsnVend(WebDriver Driver) throws Exception {

		
		VGF.Divselect();
		VGF.Vendselect();
		VGF.Exclude();
		
	}
	
	@Test
	public void Excldtbl(WebDriver Driver) throws InterruptedException  {

		Thread.sleep(5000);
		
		String Val1 = VGF.Divcol.getText() ;
		
		if (Val1.contains("15-United Retail Div #15")) {
			System.out.println("Pass");
			extentTest.log(LogStatus.INFO, "Division excluded");
		} else {
			System.out.println("Failed value is" );
			extentTest.log(LogStatus.FAIL, "Failed");
			
		}
		
String Val2 = VGF.Vendcol.getText() ;
		
		if (Val2.contains("001443-NATURAL LIFE FOODS INC")) {
			System.out.println("Pass");
			extentTest.log(LogStatus.INFO, "Vendor excluded");
		} else {
			System.out.println("Failed value is" );
			extentTest.log(LogStatus.FAIL, "Failed");
			
		}
	}
	
	
	
	

	@BeforeTest
	public void beforeTest(WebDriver Driver) {

		VGF = new VenExcPageFactory(Driver);

	}


}
