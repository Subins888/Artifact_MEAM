package AMP.Modules;


//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UnitedDepExcPageFactory {
	WebDriver Driver;

	@FindBy(xpath = "//*[@id=\'idSIButton9\']")
	WebElement Next;
	
	@FindBy(xpath ="//li[contains(text(),'Dashboard')]")
	WebElement Dashboard;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[1]/div/amp-navbar/nav/div[2]/ul/li[3]")
	WebElement Admin;	
	
	@FindBy(xpath ="//div[contains(text(),'United Department Exclusion')]")
	WebElement Unitedexcl;
	
	@FindBy(xpath ="//label[contains(text(),'1-TOBACCO')]")
	WebElement Untddata;
	
	@FindBy(xpath = "//button[@name='addBtn']")
	WebElement Addbtn;
	
	@FindBy(xpath = "//button[@id='saveBtn']")
	WebElement Savebtn;
	
	@FindBy(xpath ="//label[contains(text(),'1-TOBACCO')]")
	WebElement Untdcol;
	
	@FindBy(xpath = "//button[@name='removeBtn']")
	WebElement Removebtn;
	
	public UnitedDepExcPageFactory(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	
	public void Unitedclk() 
	{
			Admin.click();
			Unitedexcl.click();
	}
	public void Unitedselect() 
	{
		Untddata.click();
	
	}
	
	public void Exclude1() 
	{
		Addbtn.click();
		Savebtn.click();
	}
	public void Remove() 
	{
		Untddata.click();
		Removebtn.click();
		Savebtn.click();
	}
}
