package AMP.Pages;

import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


import AMP.Modules.BaseClass;
import AMP.Modules.GroupSMICExcPageobject;
import AMP.Modules.LoginPageobject;


public class AA117_GroupSMICExclusion extends BaseClass {

	WebDriver Driver;

	LoginPageobject LPO = new LoginPageobject(Driver);
	GroupSMICExcPageobject GSEPO = new GroupSMICExcPageobject(Driver);
	
	static ExtentTest test;

	static ExtentReports report;

	@Test(priority = 1, enabled = true)
	public void LoginTC() throws Exception {
		
		LPO.waitforelement();
		LPO.TC01_Login();

	}
	@Test(priority = 2, enabled = true)
	public void FirstTC() throws Exception {
		
		GSEPO.Menu(Driver);
		GSEPO.waitForSpinnerToBeGone(Driver);
		
		Thread.sleep(20000);

	}
	@Test(priority = 3, enabled = true)
	public void SecondTC() throws Exception {
		
		GSEPO.ExclsnGRP(Driver);
		GSEPO.ExcldGRPtbl(Driver);
		
	}
	@Test(priority = 4, enabled = true)
	public void ThirdTC() throws Exception {
		Thread.sleep(20000);
			 
		
	}
	
	@BeforeTest
	public void beforeTest() throws InterruptedException {

		
		Driver = LPO.beforeTest();
		GSEPO.beforeTest(Driver);
		//Thread.sleep(10000);
		extentTest = extent.startTest("AMP Test", "AA-117-Login");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
		
	}

	@AfterTest
	public void after() {

		//Driver.quit();

	}
}
