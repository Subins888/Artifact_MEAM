package AMP.Pages;

import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

//import AMP.Modules.RevGenPageFactory;
import AMP.Modules.BaseClass;

import AMP.Modules.LoginPageobject;

import AMP.Modules.VenExcPageobject;



public class AA119_VendorExclusion extends BaseClass {

	WebDriver Driver;
//	LoginPageFactory LF = new LoginPageFactory(Driver);
	LoginPageobject LPO = new LoginPageobject(Driver);
	VenExcPageobject VEPO = new VenExcPageobject(Driver);
	
	static ExtentTest test;

	static ExtentReports report;

	@Test(priority = 1, enabled = true)
	public void LoginTC() throws Exception {
		
		LPO.waitforelement();
		LPO.TC01_Login();
		//Driver.navigate().refresh();
	}
	@Test(priority = 2, enabled = true)
	public void FirstTC() throws Exception {
		
		//Driver.navigate().refresh();
		
		
		VEPO.Menu(Driver);
//		VEPO.waitForSpinnerToBeGone(Driver);
		
		

	}
	@Test(priority = 3, enabled = true)
	public void SecondTC() throws Exception {
		Thread.sleep(50000);
//		VEPO.waitforvendexcl(Driver);
		VEPO.ExclsnVend(Driver);
		Thread.sleep(5000);	 
		
	}
	@Test(priority = 4, enabled = true)
	public void ThirdTC() throws Exception {
		
		VEPO.Excldtbl(Driver);
		Thread.sleep(5000);	 
		
	}
	
	@BeforeTest
	public void beforeTest() throws InterruptedException {

		
		Driver = LPO.beforeTest();
		VEPO.beforeTest(Driver);
		//Thread.sleep(10000);
		extentTest = extent.startTest("AMP Test", "AA-119-Login");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
		
	}

	@AfterTest
	public void after() {

		//Driver.quit();

	}
}
