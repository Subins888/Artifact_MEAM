package AMP.Modules;


import org.openqa.selenium.NoAlertPresentException;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageFactory {
	WebDriver Driver;

	
	@FindBy(xpath = "//*[@id=\'i0116\']")
	WebElement Ldap;
	
	@FindBy(xpath = "//*[@id=\'idSIButton9\']")
	WebElement Next;
	
	@FindBy(xpath = "//*[@id='userNameInput']")
	WebElement Username;

	@FindBy(xpath = "//*[@id=\'passwordInput\']")
	WebElement Password;
	
	@FindBy(xpath = "//*[@id=\'submitButton\']")
	WebElement SignIn;
	
	@FindBy(xpath = "/html/body/app-root/amp-container/div/div[1]/div/amp-navbar/nav/div[3]/div[1]")
	WebElement Ldapname;
	
	@FindBy(xpath = "/html/body/app-root/amp-container/div/div[1]/div/amp-navbar/nav/div[3]/div[3]/span")
	WebElement Logout;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[1]/div/amp-navbar/nav/div[2]/ul/li[1]")
	WebElement Dashboard;
	
	
	@FindBy(xpath ="//div[@class='date mt-1']")
	WebElement Date;
	
	@FindBy(xpath = "//*[@id=\'tilesHolder\']/div/div/div/div/div[1]/img")
	WebElement Signoutacct;
	
/*	@FindBy(xpath ="//a[@id='signInAnotherWay']")
	WebElement SignAthr;
	
	//@FindBy(xpath ="//div[contains(text(),'Use a verification code from my mobile app')]")
	//@FindBy(xpath ="//*[@id='idDiv_SAOTCS_Proofs']/div[2]/div/div/div[2]/div")
	@FindBy(xpath ="//*[@id=\'idDiv_SAOTCS_Proofs\']/div[2]/div/div/div[1]/div/img")
	WebElement Usever;
	
	@FindBy(xpath ="//input[@id='idTxtBx_SAOTCC_OTC']")
	WebElement Codepass;
	
	@FindBy(xpath ="//input[@id='idSubmit_SAOTCC_Continue']")
	WebElement Verifybtn; */
	
	
	
	public LoginPageFactory(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public void enterLdapID(String LdapID) {
		Ldap.sendKeys(LdapID);
	}
	public void NextClick() throws InterruptedException {
		Next.click();
		Thread.sleep(10000);
	}
	public void UsernameVal(String UN) {
		Username.sendKeys(UN);
	}
	public void PasswordVal(String PW) {
		Password.sendKeys(PW);
	}
	public void clickSignIn() throws InterruptedException {
		SignIn.click();
		Thread.sleep(15000);
		Driver.navigate().refresh();
		

	}
	/*public void Authentication() throws InterruptedException 
	{
		String secretKey = "gkyy6vd2rfgnhyww";
		Totp totp = new Totp(secretKey);
		//totp.now();
		System.out.println(totp.now());
		Thread.sleep(4000);
		SignAthr.click();
		Thread.sleep(4000);
		Usever.click();
		Thread.sleep(4000);
		
		Codepass.sendKeys(totp.now());
		Thread.sleep(500);
		Verifybtn.click();
		Thread.sleep(10000);
		Driver.navigate().refresh();
		
		
	}*/
	
	public boolean isAlertPresent() {
        try {
            Driver.switchTo().alert().accept();
            return true;
        } catch (NoAlertPresentException e) {
            return false;
        }
		
		
    }
	public void Signoutcnfmtn() 
	{
		Signoutacct.click();
		
	}
	
}
