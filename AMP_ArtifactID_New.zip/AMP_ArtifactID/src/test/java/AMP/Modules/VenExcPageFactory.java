package AMP.Modules;

import org.openqa.selenium.Keys;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VenExcPageFactory {
	WebDriver Driver;

	@FindBy(xpath = "//*[@id=\'idSIButton9\']")
	WebElement Next;
	
	@FindBy(xpath ="//li[contains(text(),'Dashboard')]")
	WebElement Dashboard;
	
	@FindBy(xpath ="//button[@class='btn button btn-primary ml-4']")
	WebElement Searchbtn;
	
	@FindBy(xpath ="//span[@class='page-head']")
	WebElement Vendhead;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[1]/div/amp-navbar/nav/div[2]/ul/li[3]")
	WebElement Admin;	
	
	@FindBy(xpath ="//*[@id=\'ngb-popover-1\']/div[2]/amp-menu-pop-over/div/div[2]")
	WebElement Vendexcl;
	
	//@FindBy(xpath ="//ng-select[@id='division']//input")
	@FindBy(xpath ="(//div[@class='ng-input']//input)[1]")
	WebElement Div;
	
	//@FindBy(xpath = "//*[@id=\'division\']/div/div/div[2]/input")
	@FindBy(xpath="//input[@type='text']")
	WebElement Divisiondrop;

	
	@FindBy(xpath ="//*[@id=\'vendor_nmAdnbr_search_non-united\']/div/div/div[2]/input")
	WebElement vendordrop;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[2]/div/div[2]/amp-vendor-exclusion/div/form/div[1]/i")
	WebElement vendsearch;
	
	//@FindBy(xpath = "//*/div[2]/div/span" )
	@FindBy(xpath = "//div[@class='ng-option ng-option-marked']//span[1]")
	WebElement vendnatural;
	
	@FindBy(xpath = "//*[@id=\'label\']")
	WebElement Reason;
	
	@FindBy(xpath = "//*[@id=\"saveBtn\"]")
	WebElement Excldbtn;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[2]/div/div[2]/amp-vendor-exclusion/div/form/div[2]/amp-datatable/div/div/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span/p")
	WebElement Divcol;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[2]/div/div[2]/amp-vendor-exclusion/div/form/div[2]/amp-datatable/div/div/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span/p")
	WebElement Vendcol;
	
	public VenExcPageFactory(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	
	public void Vendclk() 
	{
			Admin.click();
			Vendexcl.click();
	}
	public void Divselect() 
	{
		Div.click();
		Divisiondrop.sendKeys("15-United Retail Div #15", Keys.ENTER);
		
		
	
	}
	public void Vendselect() 
	{
		vendordrop.click();
		vendordrop.sendKeys("001443", Keys.ENTER);
		vendsearch.click();
		vendnatural.click();
	
	}
	public void Exclude() 
	{
		
		Reason.sendKeys("Test Automation", Keys.ENTER);
		Excldbtn.click();
	
	}
}
