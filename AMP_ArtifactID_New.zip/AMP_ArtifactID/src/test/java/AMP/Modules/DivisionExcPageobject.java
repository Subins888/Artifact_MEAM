package AMP.Modules;

//import java.io.File;
//import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.By;
//import org.openqa.selenium.By;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


/*import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;*/

public class DivisionExcPageobject extends BaseClass {

	WebDriver Driver;
	LoginPageFactory LF = new LoginPageFactory(Driver);
	DivisionExcPageFactory DGF = new DivisionExcPageFactory(Driver);
	
	static ExtentTest test;
	static ExtentReports report;

	public DivisionExcPageobject (WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	public String aftermthd(WebDriver Driver) throws IOException {

		TakesScreenshot ts = (TakesScreenshot) Driver;
		String source1 = ts.getScreenshotAs(OutputType.BASE64);
		return source1;

	}
	public String waitforDivexcl(WebDriver Driver) {

		WebDriverWait wait = new WebDriverWait(Driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(DGF.Allbtn));

		return null;
	}
	
	public String waitForSpinnerToBeGone(WebDriver Driver) {

		//By loadingImage = By.id("amp-spinner");
		By loadingImage = By
		.xpath("*[@id='amp-spinner']");
		// WebDriverWait wait = new WebDriverWait(Driver);
		// wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingImage));
		WebDriverWait wait = new WebDriverWait(Driver, 300);
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(loadingImage));
		return null;
	}
	

	
	@Test
	public void Menu(WebDriver Driver) throws Exception {

		Thread.sleep(1000);
		DGF.Divisionclk();
		Thread.sleep(5000);

	}

	@Test
	public void ExclsnDivsn(WebDriver Driver) throws Exception {

		Thread.sleep(5000);
		DGF.Divisionselect();
		DGF.Exclude1();
		
		
	}
	
	@Test
	public void ExcldDivtbl(WebDriver Driver) throws InterruptedException  {

		Thread.sleep(5000);
		
		String Val1 = DGF.DivicolR.getText() ;
		
		if (Val1.contains("01-Albertsons Specialty Care")) {
			System.out.println("Division Value 01 is excluded");
			extentTest.log(LogStatus.INFO, "Division Value excluded");
		} else {
			System.out.println("Division Value exclusion Failed" );
			extentTest.log(LogStatus.FAIL, "Division Value exclusion Failed");
			}		
	}
		
	@Test
	public void RemvDivtbl(WebDriver Driver) throws InterruptedException  {

		Thread.sleep(5000);
		DGF.Remove();
		
		Thread.sleep(5000);
		String Val2 = DGF.DivicolA.getText() ;
		
		if (Val2.contains("01-Albertsons Specialty Care")) {
			System.out.println("Division Value exclusion is removed");
			extentTest.log(LogStatus.INFO, "Division Value exclusion is removed successfully");
		} else {
			System.out.println("Division Value remove failed" );
			extentTest.log(LogStatus.FAIL, "Division Value remove failed");
			}		
	}
	

	@BeforeTest
	public void beforeTest(WebDriver Driver) {

		DGF = new DivisionExcPageFactory(Driver);

	}


}
