package All;

public class Basic {

}
