package AMP_Group.AMP_ArtifactID;

import java.io.IOException;

import jxl.read.biff.BiffException;

import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Userstory extends ExtendBaseClass {

      WebDriver Driver;
      SSPageObject PO = new SSPageObject(Driver);
      static ExtentTest test;

      static ExtentReports report;

      @Test
      public void FrstMthd() throws BiffException, IOException,
                  InterruptedException {

            PO.waitforelement();
            PO.Login();

      }

      @BeforeTest
      public void beforeTest() {

            Driver = PO.beforeTest();
            extentTest = extent.startTest("Mercury Tours Test", "Signon Click");
            extentTest.log(LogStatus.INFO, "Browser successfully launched");
      }

      @AfterTest
      public WebDriver after() {

            return PO.afterTest();

      }
}
