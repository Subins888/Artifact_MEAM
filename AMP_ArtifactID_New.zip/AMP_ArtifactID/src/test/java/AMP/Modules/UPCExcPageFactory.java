package AMP.Modules;

import org.openqa.selenium.Keys;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UPCExcPageFactory {
	WebDriver Driver;

	@FindBy(xpath = "//*[@id=\'idSIButton9\']")
	WebElement Next;
	
	@FindBy(xpath ="//li[contains(text(),'Dashboard')]")
	WebElement Dashboard;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[1]/div/amp-navbar/nav/div[2]/ul/li[3]")
	WebElement Admin;	
	
	@FindBy(xpath ="//*[@id=\"ngb-popover-1\"]/div[2]/amp-menu-pop-over/div/div[3]")
	WebElement Upcexcl;
	
	@FindBy(xpath ="//ng-select[@id='division']//input")
	WebElement Div;
	
	@FindBy(xpath = "//*[@id=\"division\"]/div/div/div[2]/input")
	WebElement Divisiondrop;
	
	@FindBy(xpath ="//*[@id=\"upcId\"]")
	WebElement Upctype;
	
	@FindBy(xpath = "//*[@id=\"label\"]")
	WebElement Reason;
	
	@FindBy(xpath = "//*[@id=\"excludeBtn\"]")
	WebElement Excldbtn;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[2]/div/div[2]/amp-upc-exclusion/div/form/div[3]/amp-datatable/div/div/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[7]/datatable-body-row/div[2]/datatable-body-cell[2]/div/div/span/p")
	WebElement Divcol;
	
	@FindBy(xpath ="/html/body/app-root/amp-container/div/div[2]/div/div[2]/amp-upc-exclusion/div/form/div[3]/amp-datatable/div/div/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[7]/datatable-body-row/div[2]/datatable-body-cell[3]/div/div/span/p")
	WebElement UPCcol;
	
	public UPCExcPageFactory(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}

	
	public void Upcclk() 
	{
			Admin.click();
			Upcexcl.click();
	}
	public void Divselect2() 
	{
		Div.click();
		Divisiondrop.sendKeys("15-United Retail Div #15", Keys.ENTER);
		
	
	}
	public void UPCTYPE() 
	{
		Upctype.click();
		Upctype.sendKeys("123456789100", Keys.ENTER);
		
	
	}
	public void Exclude2() 
	{
		
		Reason.sendKeys("Test Automation UPC", Keys.ENTER);
		Excldbtn.click();
	
	}
}
