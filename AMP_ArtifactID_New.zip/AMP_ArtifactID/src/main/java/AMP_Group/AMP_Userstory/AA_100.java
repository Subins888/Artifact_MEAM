/*package AMP_Group.AMP_Userstory;

import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import AMP_Group.AMP_ArtifactID.BaseClass;

import AMP_Group.AMP_ArtifactID.SSGenericFactory;
import AMP_Group.AMP_ArtifactID.SSPageObject;

public class AA_100 extends BaseClass {

	WebDriver Driver;
	SSGenericFactory GF = new SSGenericFactory(Driver);
	SSPageObject PO = new SSPageObject(Driver);
	static ExtentTest test;


	static ExtentReports report;

	
	@Test(priority = 1, enabled = true)
	public void AA_100_FrstMthd() throws Exception {

		PO.waitforelement();
		PO.Login();
		

	}
	@Test(priority = 2, enabled = true)
	public void AA_100_ScndMthd() throws Exception {

		
		PO.Menu();
		Thread.sleep(7000);
		PO.Genarate();
		Thread.sleep(7000);
		
		
	}
	
	@Test(priority = 3, enabled = true)
	public void AA_100_ThirdMthd() throws Exception {
		
		PO.GenPopup();
		Thread.sleep(5000);
		
		PO.WaitstartGen();
		PO.GenerateStart();
		
		PO.WaitDSDGen();
		PO.GenerateDSD();
		PO.WaitUNITEDGen();
		PO.GenerateUNITED();
		PO.WaitWHSEGen();
		PO.GenerateWHSE();
		PO.WaitSBTGen();
		PO.GenerateSBT();
		
		PO.WaitcompltGen();
		PO.GenerateDis();
		
	}
	
	@BeforeTest
	public void beforeTest() {

		Driver = PO.beforeTest();
		extentTest = extent.startTest("AMP Test", "Home Page");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
	}

	@AfterTest
	public WebDriver after() {

		return PO.afterTest();

	}
}
*/