package AMP.Pages;

import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import AMP.Modules.LoginPageFactory;
import AMP.Modules.BaseClass;

import AMP.Modules.LoginPageobject;



public class AA310_Login extends BaseClass {

	WebDriver Driver;
	LoginPageFactory LF = new LoginPageFactory(Driver);
	LoginPageobject LPO = new LoginPageobject(Driver);
	static ExtentTest test;

	static ExtentReports report;

	@Test(priority = 1, enabled = true)
	public void FirstTC() throws Exception {
		
		LPO.waitforelement();
		LPO.TC01_Login();

	}
	@Test(priority = 2, enabled = true)
	public void SixthTC() throws Exception {

		//LPO.waitForSpinnerToBeGone();
		LPO.TC06_LDAPtxt();

	}
	@Test(priority = 3, enabled = true)
	public void SeventhTC() throws Exception {

		 LPO.waitForSpinnerToBeGone();
		LPO.TC07_Logout();

	}
	
	@BeforeTest
	public void beforeTest() throws InterruptedException {

		Driver = LPO.beforeTest();
		//Thread.sleep(10000);
		extentTest = extent.startTest("AMP Test", "AA-334-Login");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
		
	}

	@AfterTest
	public void after() {

		//Driver.quit();

	}
}
