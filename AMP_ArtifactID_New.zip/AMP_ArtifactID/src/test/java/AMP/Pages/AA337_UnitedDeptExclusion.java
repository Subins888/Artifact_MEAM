package AMP.Pages;

import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


import AMP.Modules.BaseClass;
import AMP.Modules.LoginPageobject;
import AMP.Modules.UnitedDepExcPageobject;


public class AA337_UnitedDeptExclusion extends BaseClass {

	WebDriver Driver;

	LoginPageobject LPO = new LoginPageobject(Driver);
	UnitedDepExcPageobject UDEPO = new UnitedDepExcPageobject(Driver);
	
	static ExtentTest test;

	static ExtentReports report;

	@Test(priority = 1, enabled = true)
	public void LoginTC() throws Exception {
		
		LPO.waitforelement();
		LPO.TC01_Login();

	}
	@Test(priority = 2, enabled = true)
	public void FirstTC() throws Exception {
		
		UDEPO.Menu(Driver);
		UDEPO.waitForSpinnerToBeGone(Driver);
		
		Thread.sleep(20000);

	}
	@Test(priority = 3, enabled = true)
	public void SecondTC() throws Exception {
		
		UDEPO.ExclsnUnited(Driver);
		UDEPO.ExcldUnitedtbl(Driver);
		
	}
	@Test(priority = 4, enabled = true)
	public void ThirdTC() throws Exception {
		
		UDEPO.RemvUntdtbl(Driver); 
		
	}
	
	@BeforeTest
	public void beforeTest() throws InterruptedException {

		
		Driver = LPO.beforeTest();
		UDEPO.beforeTest(Driver);
		//Thread.sleep(10000);
		extentTest = extent.startTest("AMP Test", "AA-337-Login");
		extentTest.log(LogStatus.INFO, "Browser successfully launched");
		
	}

	@AfterTest
	public void after() {

		//Driver.quit();

	}
}
